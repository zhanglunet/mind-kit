# 第二大脑安装与飞书备份专家

这是一个供 WorkBuddy 导入或提交审核的专家包。

## 包含内容

- `expert.yaml`：专家元数据和隐私声明。
- `SKILL.md`：安装、授权、同步、编译和安全边界。

## 安全声明

本包不包含任何 App Secret、Token、个人飞书内容、仓库凭证或本地路径。专家只在用户明确确认后指导本机执行安装器和同步；飞书授权始终由用户本人完成。

## 官方说明

- 使用指南：<https://aip.cab/workbuddy>
- 公开安装仓库：<https://github.com/zhanglunet/mind-kit>

