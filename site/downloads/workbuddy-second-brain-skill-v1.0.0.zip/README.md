# 第二大脑 WorkBuddy 技能包

这是一个供 WorkBuddy 用户导入的个人技能包。

## 包含内容

- `skill.yaml`：技能元数据和隐私声明。
- `SKILL.md`：安装、授权、同步、编译和安全边界。

## 安全声明

本包不包含任何 App Secret、Token、个人飞书内容、仓库凭证或本地路径。技能只在用户明确确认后指导本机执行安装器和同步；飞书授权始终由用户本人完成。

本包是个人可导入技能，不代表 WorkBuddy 官方技能市场或专家市场已经审核上架。

## 官方说明

- 使用指南：<https://aip.cab/workbuddy>
- 公开安装仓库：<https://github.com/zhanglunet/mind-kit>
